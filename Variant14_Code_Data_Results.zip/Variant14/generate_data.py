"""Генерация исходных данных варианта 14."""
import numpy as np

from common import SEED, write_data


def coal(rng):
    return {
        "seed": SEED,
        "suppliers": ["S1", "S2", "S3", "S4", "S5"],
        "price": ([5200, 5400, 5850, 6350, 6500] + rng.integers(-35, 36, 5)).tolist(),
        "capacity": ([380, 370, 320, 300, 240] + rng.integers(-9, 10, 5)).tolist(),
        "ash_pct": ((np.array([170, 80, 104, 53, 131]) + rng.integers(-2, 3, 5)) / 10).tolist(),
        "sulfur_pct": ((np.array([65, 175, 93, 69, 34]) + rng.integers(-2, 3, 5)) / 100).tolist(),
        "demand": 1000,
        "ash_limit_pct": 11.0,
        "sulfur_limit_pct": 1.04,
        "stress_ash_limit_pct": 7.9,
    }


def taxis(rng):
    # Дуги из зон с избытком в зоны с нехваткой и два транзитных маршрута.
    base_arcs = [(1, 5, 25, 19), (1, 6, 35, 40), (1, 7, 40, 24),
                 (2, 5, 35, 24), (2, 6, 40, 26), (2, 7, 40, 55),
                 (3, 5, 35, 47), (3, 6, 15, 20), (3, 7, 35, 30),
                 (1, 2, 15, 13), (5, 7, 18, 14),
                 (4, 8, 25, 23), (4, 5, 12, 53), (2, 8, 16, 45)]
    arcs = [
        {"tail": i, "head": j, "capacity": cap + int(rng.integers(-2, 3)),
         "cost": cost + int(rng.integers(0, 3))}
        for i, j, cap, cost in base_arcs
    ]
    return {"seed": SEED, "balance": [40, 35, 25, 20, -30, -35, -35, -20], "arcs": arcs}


def teams(rng):
    count, team_count = 72, 18
    roles = np.arange(count) % 3
    fees = rng.integers(7, 21, count)
    assignment = rng.integers(12, 65, (count, team_count))
    conflicts = [(1, 2), (1, 3), (2, 6), (4, 5), (5, 9), (7, 8), (8, 12), (10, 11), (1, 6), (2, 10)]
    for i in range(1, count + 1):
        for j in range(max(i + 1, 13), min(i + 15, count + 1)):
            if roles[i - 1] != roles[j - 1] and rng.random() < 0.13:
                conflicts.append((i, j))
    return {
        "seed": SEED, "roles": roles.tolist(),
        "role_names": ["Руководитель", "Разработчик", "Аналитик"],
        "fee": fees.tolist(), "assignment_cost": assignment.tolist(),
        "conflicts": conflicts,
    }


if __name__ == "__main__":
    for index, (lab, build) in enumerate(
        [("lab1", coal), ("lab2", taxis), ("lab3", teams)], start=1
    ):
        rng = np.random.default_rng(np.random.SeedSequence([SEED, index]))
        write_data(lab, build(rng))
