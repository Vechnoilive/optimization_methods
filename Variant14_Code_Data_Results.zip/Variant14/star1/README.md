# Задание со звёздочкой к ЛР № 1

Эластичный фильтр для зольности. Используются данные ЛР № 1.

Из корня архива в Python 3.12.

```bash
python -m pip install -r requirements.txt
python -m star1.main > star1/results/solver.log 2>&1
```

Результаты лежат в `results`.
