"""Эластичный фильтр для предела зольности."""
import numpy as np

from common import TOL, read_data, require_status, solve_lp, write_check, write_csv
from lab1.main import build_model, deficit_capacity, fill_cheapest, inputs, verify


def run_star(data):
    price, capacity, ash, sulfur = inputs(data)
    capacity = deficit_capacity(capacity)
    demand = data["demand"]
    ash_limit = data["stress_ash_limit_pct"]
    sulfur_limit = data["sulfur_limit_pct"]
    base = build_model(capacity, ash, sulfur, demand, ash_limit, sulfur_limit)
    model = dict(base, A_ub=np.column_stack((base["A_ub"], [-demand, 0])),
                 A_eq=np.column_stack((base["A_eq"], [0])),
                 bounds=[*map(tuple, base["bounds"]), (0, None)])
    elastic = np.r_[np.zeros(len(price)), 1]
    repair = solve_lp(elastic, label="minimum ash relaxation", **model)
    require_status(repair, 0)

    # В сертификате используем равный взвешенный коэффициент для S2 и S5.
    lam = (ash[4] - ash[1]) / (sulfur[1] - sulfur[4])
    weight = ash + lam * sulfur
    bound = float(weight @ fill_cheapest(weight, capacity, demand) / demand - lam * sulfur_limit)
    assert abs(repair.fun - (bound - ash_limit)) <= TOL

    repaired_limit = ash_limit + repair.fun
    restored = solve_lp(price, label="least cost at restored ash limit",
                        **build_model(capacity, ash, sulfur, demand, repaired_limit, sulfur_limit))
    require_status(restored, 0)
    checks = verify(restored.x, price, capacity, ash, sulfur, demand, repaired_limit,
                    sulfur_limit, restored.fun)
    checks.update(minimum_increase=float(repair.fun), certified_minimum_ash=bound,
                  repaired_ash_limit=float(repaired_limit),
                  achieved_ash_pct=float(ash @ restored.x / demand),
                  achieved_sulfur_pct=float(sulfur @ restored.x / demand))
    write_csv("star1", "repair", ["original_ash_limit", "increase", "repaired_ash_limit", "cost"],
              [[ash_limit, repair.fun, repaired_limit, restored.fun]])
    write_csv("star1", "solution", ["supplier", "tonnes"], zip(data["suppliers"], restored.x))
    write_check("star1", "checks", checks)


if __name__ == "__main__":
    run_star(read_data("lab1"))
