# ЛР № 1. Смешение углей для ТЭС

Вариант 14. Цены, лимиты, зольность и содержание серы получены небольшим случайным разбросом от шаблона. Данные лежат в `data.json`. Seed генерации — `10011`.

Из корня архива в Python 3.12.

```bash
python -m pip install -r requirements.txt
python -m lab1.main > lab1/results/solver.log 2>&1
```

В `results` сохранены CSV, независимая проверка и лог HiGHS.
