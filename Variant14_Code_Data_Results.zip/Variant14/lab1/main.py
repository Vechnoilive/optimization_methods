"""Подбор угольной смеси с заданным объёмом, зольностью и серой."""
import numpy as np

from common import (STATUS, TOL, max_violation, read_data, require_status, solve_lp,
                    verify_objective, write_check, write_csv)


def inputs(data):
    return tuple(np.array(data[key], dtype=float) for key in
                 ("price", "capacity", "ash_pct", "sulfur_pct"))


def build_model(capacity, ash, sulfur, demand, ash_limit, sulfur_limit):
    return dict(A_ub=np.vstack((ash, sulfur)), b_ub=demand * np.array([ash_limit, sulfur_limit]),
                A_eq=np.ones((1, len(capacity))), b_eq=[demand],
                bounds=np.column_stack((np.zeros(len(capacity)), capacity)))


def verify(plan, price, capacity, ash, sulfur, demand, ash_limit, sulfur_limit, objective):
    checks = {"volume": abs(float(plan.sum()) - demand),
              "upper": max_violation(plan - capacity), "lower": max_violation(-plan),
              "ash_pct": max(float(ash @ plan / demand - ash_limit), 0),
              "sulfur_pct": max(float(sulfur @ plan / demand - sulfur_limit), 0)}
    return verify_objective(checks, objective, price @ plan)


def fill_cheapest(weight, capacity, demand):
    # Один баланс и верхние границы: заполняем объём в порядке роста коэффициента.
    plan = np.zeros_like(capacity)
    remaining = demand
    for i in np.argsort(weight):
        plan[i] = min(capacity[i], remaining)
        remaining -= plan[i]
    if remaining > TOL:
        raise ValueError("Поставщики не покрывают заданный объём")
    return plan


def deficit_capacity(capacity):
    reduced = capacity.copy()
    reduced[1] *= 0.8
    return reduced


def run_lab(data):
    price, capacity, ash, sulfur = inputs(data)
    demand, ash_limit, sulfur_limit = (data[key] for key in
                                      ("demand", "ash_limit_pct", "sulfur_limit_pct"))
    reduced = deficit_capacity(capacity)
    increased = capacity.copy()
    increased[0] += 1
    scenarios = [
        ("base", capacity, ash_limit, sulfur_limit, 0),
        ("deficit", reduced, ash_limit, sulfur_limit, 0),
        ("stress", reduced, data["stress_ash_limit_pct"], sulfur_limit, 2),
        ("s1_plus_one", increased, ash_limit, sulfur_limit, 0),
        ("ash_plus", capacity, ash_limit + 0.1, sulfur_limit, 0),
        ("sulfur_plus", capacity, ash_limit, sulfur_limit + 0.01, 0),
    ]
    checks, summary, plans, marginals = {}, [], [], []
    for name, cap, a_max, s_max, expected in scenarios:
        result = solve_lp(price, label=name, **build_model(cap, ash, sulfur, demand, a_max, s_max))
        require_status(result, expected)
        if result.status == 2:
            lower_bound = float(ash @ fill_cheapest(ash, cap, demand) / demand)
            assert lower_bound > a_max + TOL
            checks[name] = {"min_ash_without_sulfur": lower_bound, "ash_limit": a_max}
            summary.append([name, cap[1], a_max, s_max, STATUS[result.status], "", "", "", result.nit])
            continue
        plan = result.x
        checks[name] = verify(plan, price, cap, ash, sulfur, demand, a_max, s_max, result.fun)
        summary.append([name, cap[1], a_max, s_max, STATUS[result.status], result.fun,
                        ash @ plan / demand, sulfur @ plan / demand, result.nit])
        plans.extend([name, supplier, cap[i], plan[i], plan[i] * price[i]]
                     for i, supplier in enumerate(data["suppliers"]))
        if name == "base":
            for k, quality in enumerate(("ash_limit_pct", "sulfur_limit_pct")):
                marginals.append([quality, result.ineqlin.residual[k] / demand,
                                  result.ineqlin.marginals[k] * demand])
            marginals.append(["volume_at_fixed_quality", 0, result.eqlin.marginals[0]
                              + result.ineqlin.marginals @ [ash_limit, sulfur_limit]])
            for i, supplier in enumerate(data["suppliers"]):
                marginals.append([supplier, result.upper.residual[i], result.upper.marginals[i]])
                marginals.append([f"{supplier}_lower", result.lower.residual[i], result.lower.marginals[i]])
    write_csv("lab1", "scenarios",
              ["scenario", "s2_capacity", "ash_limit", "sulfur_limit", "status", "cost",
               "actual_ash", "actual_sulfur", "iterations"], summary)
    write_csv("lab1", "solution", ["scenario", "supplier", "capacity", "tonnes", "cost"], plans)
    write_csv("lab1", "marginals", ["constraint", "slack", "marginal"], marginals)
    write_check("lab1", "checks", checks)


if __name__ == "__main__":
    run_lab(read_data("lab1"))
