"""Балансировка свободных машин между восемью городскими зонами."""
from heapq import heappop, heappush

import numpy as np

from common import (ROOT, STATUS, TOL, max_violation, read_data, require_status, solve_lp,
                    verify_objective, write_check, write_csv)


def inputs(data):
    arcs = np.array([(arc["tail"], arc["head"]) for arc in data["arcs"]]) - 1
    return (arcs, np.array([arc["cost"] for arc in data["arcs"]]),
            np.array([arc["capacity"] for arc in data["arcs"]]),
            np.array(data["balance"]))


def incidence(arcs, count):
    matrix = np.zeros((count, len(arcs)))
    columns = np.arange(len(arcs))
    matrix[arcs[:, 0], columns] = 1
    matrix[arcs[:, 1], columns] = -1
    return matrix


def solve(arcs, cost, capacity, balance, label):
    matrix = incidence(arcs, len(balance))
    # Последняя строка баланса следует из остальных и суммы b = 0.
    if abs(balance.sum()) > TOL:
        raise ValueError("Zone balances must sum to zero")
    return solve_lp(cost, label=label, A_eq=matrix[:-1], b_eq=balance[:-1],
                    bounds=np.column_stack((np.zeros(len(arcs)), capacity)))


def verify(flow, arcs, cost, capacity, balance, objective):
    net = np.zeros(len(balance))
    np.add.at(net, arcs[:, 0], flow)
    np.add.at(net, arcs[:, 1], -flow)
    checks = {
        "zone_balance": max_violation(abs(net - balance)),
        "arc_upper": max_violation(flow - capacity),
        "arc_lower": max_violation(-flow),
    }
    return verify_objective(checks, objective, np.dot(cost, flow)), net


def shortest_delivery(arcs, cost, spare, need):
    queue = [(0, int(source), (), int(source)) for source in np.flatnonzero(need > TOL)]
    best = set()
    while queue:
        tariff, source, path, node = heappop(queue)
        if node in best:
            continue
        best.add(node)
        if need[node] < -TOL:
            return source, node, path
        for index in np.flatnonzero((arcs[:, 0] == node) & (spare > TOL)):
            head = int(arcs[index, 1])
            heappush(queue, (tariff + cost[index], source, (*path, index), head))
    raise ValueError("Greedy routing cannot satisfy remaining demand")


def greedy(arcs, cost, capacity, balance):
    spare, need = capacity.astype(float), balance.astype(float)
    flow = np.zeros(len(arcs))
    while np.max(need) > TOL:
        source, target, path = shortest_delivery(arcs, cost, spare, need)
        edges = list(path)
        amount = min(need[source], -need[target], *spare[edges])
        need[source] -= amount
        need[target] += amount
        flow[edges] += amount
        spare[edges] -= amount
    return flow


def draw_network(arcs, capacity, flow, balance):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    pos = np.array([(0, 3), (0, 2), (0, 1), (0, 0),
                    (5, 3), (5, 2), (5, 1), (5, 0)])
    labels = [(1.10, 3.09), (1.37, 2.78), (2.1, 2.25), (2.05, 2.49),
              (4.37, 2.08), (1.20, 1.72), (0.79, 1.37), (3.95, 1.83),
              (2.70, 0.93), (-0.42, 2.51), (5.69, 2.03), (2.9, -0.10),
              (3.85, 2.35), (3.81, 0.47)]
    fig, ax = plt.subplots(figsize=(7.1, 4.25))
    for e, ((i, j), (lx, ly)) in enumerate(zip(arcs, labels)):
        active = flow[e] > TOL
        bend = {9: 0.22, 10: -0.48}.get(e, 0)
        ax.annotate("", xy=pos[j], xytext=pos[i],
                    arrowprops=dict(arrowstyle="-|>", color="#171717" if active else "#7d7d7d",
                                    linestyle="-" if active else "--",
                                    linewidth=1.45 if active else 0.8, shrinkA=14, shrinkB=14,
                                    connectionstyle=f"arc3,rad={bend}"))
        ax.text(lx, ly, f"{flow[e]:g}/{capacity[e]:g}", ha="center", va="center",
                fontsize=10, zorder=3, bbox=dict(boxstyle="round,pad=0.12", fc="white", ec="none"))
    for k, (x, y) in enumerate(pos):
        ax.scatter(x, y, s=620, facecolor="white", edgecolor="#171717", linewidth=1.2, zorder=4)
        ax.text(x, y, f"Z{k + 1}", ha="center", va="center", zorder=5)
        ax.text(x - 0.3 if k < 4 else x + 0.32, y + 0.23, f"{balance[k]:+g}",
                ha="right" if k < 4 else "left", fontsize=10, zorder=5)
    ax.set(xlim=(-0.98, 6.10), ylim=(-0.33, 3.49))
    ax.axis("off")
    fig.savefig(ROOT / "lab2/results/network.pdf", bbox_inches="tight", pad_inches=0.03)
    plt.close(fig)
    return fig


def run_lab(data):
    arcs, cost, capacity, balance = inputs(data)
    base = solve(arcs, cost, capacity, balance, "base")
    require_status(base, 0)
    # При одинаковой загрузке в процентах выбираем больший поток.
    busiest = max(range(len(arcs)), key=lambda i: (base.x[i] / capacity[i], base.x[i], -i))
    congested, failed = capacity.astype(float), capacity.copy()
    congested[busiest] *= 0.75
    failed[busiest] = 0
    growth = balance * 1.2
    summary, solution, arc_rows, node_rows, checks = [], [], [], [], {}
    base_cost = base.fun
    for name, cap, b, result in [
        ("base", capacity, balance, base),
        ("congestion", congested, balance, None),
        ("growth", capacity, growth, None),
        ("failure", failed, balance, None),
    ]:
        if result is None:
            result = solve(arcs, cost, cap, b, name)
        require_status(result, 0)
        summary.append([name, cap[busiest], -b[b < 0].sum(), STATUS[result.status], result.fun,
                        result.fun - base_cost, result.nit])
        checks[name], net = verify(result.x, arcs, cost, cap, b, result.fun)
        potentials = np.r_[result.eqlin.marginals, 0]
        for k, b_k in enumerate(b):
            node_rows.append([name, k + 1, b_k, net[k], net[k] - b_k, potentials[k]])
        for e, (i, j) in enumerate(arcs):
            solution.append([name, i + 1, j + 1, cap[e], result.x[e], cost[e], cost[e] * result.x[e]])
            if name == "base":
                arc_rows.append([i + 1, j + 1, cap[e] - result.x[e], result.upper.marginals[e]])
    heuristic = greedy(arcs, cost, capacity, balance)
    greedy_cost = cost @ heuristic
    checks["greedy"], _ = verify(heuristic, arcs, cost, capacity, balance, greedy_cost)
    summary.append(["greedy", capacity[busiest], -balance[balance < 0].sum(), "feasible",
                    greedy_cost, greedy_cost - base_cost, ""])
    for e, (i, j) in enumerate(arcs):
        solution.append(["greedy", i + 1, j + 1, capacity[e], heuristic[e], cost[e],
                         cost[e] * heuristic[e]])
    write_csv("lab2", "scenarios",
              ["scenario", "busiest_arc_capacity", "demand", "status", "cost", "delta", "iterations"],
              summary)
    write_csv("lab2", "solution", ["scenario", "tail", "head", "capacity", "flow", "tariff", "cost"],
              solution)
    write_csv("lab2", "nodes", ["scenario", "zone", "balance", "net_flow", "error", "potential"],
              node_rows)
    write_csv("lab2", "arc_marginals", ["tail", "head", "slack", "marginal"], arc_rows)
    write_check("lab2", "checks", checks)
    return draw_network(arcs, capacity, base.x, balance)


if __name__ == "__main__":
    run_lab(read_data("lab2"))
