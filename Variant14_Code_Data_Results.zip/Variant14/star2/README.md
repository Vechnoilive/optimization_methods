# Задание со звёздочкой к ЛР № 2

Двойственная задача. Используются данные ЛР № 2.

Из корня архива в Python 3.12.

```bash
python -m pip install -r requirements.txt
python -m star2.main > star2/results/solver.log 2>&1
```

Результаты лежат в `results`.
