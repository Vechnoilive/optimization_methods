"""Самостоятельное решение двойственной модели сети переброски такси."""
import numpy as np

from common import TOL, max_violation, read_data, require_status, solve_lp, write_check, write_csv
from lab2.main import incidence, inputs, solve, verify


def solve_dual(arcs, cost, capacity, balance):
    count = len(balance)
    matrix = incidence(arcs, count)
    bounds = [(None, None)] * (count - 1) + [(0, 0)] + [(0, None)] * len(cost)
    return solve_lp(np.r_[-balance, capacity], label="dual: maximize b*p - u*l",
                    A_ub=np.column_stack((matrix.T, -np.eye(len(cost)))),
                    b_ub=cost, bounds=bounds)


def run_star(data):
    arcs, cost, capacity, balance = inputs(data)
    primal = solve(arcs, cost, capacity, balance, "primal: base")
    dual = solve_dual(arcs, cost, capacity, balance)
    require_status(primal, 0)
    require_status(dual, 0)
    pi, mu = np.split(dual.x, [len(balance)])
    tail, head = arcs.T
    reduced_cost = cost - pi[tail] + pi[head] + mu
    objective = balance @ pi - capacity @ mu
    checks, _ = verify(primal.x, arcs, cost, capacity, balance, primal.fun)
    checks.update({
        "dual_feasibility": max(max_violation(-reduced_cost), max_violation(-mu)),
        "arc_lower_complementarity": max_violation(abs(reduced_cost * primal.x)),
        "arc_upper_complementarity": max_violation(abs(mu * (capacity - primal.x))),
        "dual_objective_error": abs(objective + dual.fun),
        "duality_gap": abs(primal.fun - objective),
    })
    assert all(value <= TOL for key, value in checks.items() if key != "objective_recomputed")
    checks["dual_objective"] = float(objective)
    write_check("star2", "checks", checks)
    write_csv("star2", "potentials", ["zone", "balance", "potential", "contribution"],
              ((i + 1, b, p, b * p) for i, (b, p) in enumerate(zip(balance, pi))))
    write_csv("star2", "arc_multipliers", ["tail", "head", "capacity", "flow", "mu", "reduced_cost"],
              ((i + 1, j + 1, u, x, m, r)
               for (i, j), u, x, m, r in zip(arcs, capacity, primal.x, mu, reduced_cost)))


if __name__ == "__main__":
    run_star(read_data("lab2"))
